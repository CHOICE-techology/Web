# CHOICE iD Identity Studio: review room

A public, review-only folder. It holds images, short conclusions and next-step prompts so that different reviewers (people and AI tools) can see the same evidence. It contains no site code and nothing from the private repository.

How to read it:
1. `STATUS.md`: where we are and what is waiting for a decision.
2. `NEXT-STEP.md`: the proposed next step and the exact prompt for it.
3. `images/<date>-<gate>/`: the pictures for that gate. Direct links work in any tool.
4. `video/`: recordings (exact-frame, no blending).

Rules that hold: no pink, cyan #34FAFB only as a signal, no invented product UI, stop at each gate for approval.
